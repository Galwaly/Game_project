# ChineseChesses 双人中国象棋
## 是什么
C++ 课程设计，在大一的时候写的，用到了面向对象的编程思路、Windows 编程技术、GDI 绘图等

## 怎么使用
```
git clone https://github.com/FlyAndNotDown/ChineseChesses.git
```
编译所有的文件即可
